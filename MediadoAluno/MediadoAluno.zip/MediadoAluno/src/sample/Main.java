package sample;





class Main {

    public static void main(String[] args) {

        //media aluno

        // double p1 = 10;
        // double p2 = 2;
        // double media = (p1+p2)/2;

        //  System.out.println("Média: " + media);
        // if(media >= 6){
        // System.out.println("Aprovado!");

        // }else{

        //  System.out.println("exame!");

        //  double novaP = 5;
        //  double novaMedia = (media+novaP)/2;

        //  System.out.println("Nova Média: " + novaMedia);
        //  if(novaMedia >= 6) {
        //     System.out.println("Aprovado em exame!");
        //  }else{
        //    System.out.println("Reprovado em exame!");
        //  }


        //nadador

        //   int idade = 19;
        //   if(idade <=10){
        //       System.out.println("nadador categoria infantil");
        //    }
        //   if(idade <=13){
        //        System.out.println("nadador categoria infanto juvenil");
        //     }
//     if(idade<=18){
        //        System.out.println("nadador categoriajuvenil");
        //    }else{
        //       System.out.println("nadador categoria adulto");
        //    }


        //Lanches

        // int codigo = 2;
        // int qtd = 1;
        //  double preco = 0;

        //  if (codigo == 1){
        //     preco = 4.00 * qtd;
        //  }
        //  if (codigo == 2) {
        //      preco = 4.50 * qtd;
        //  }
        //  if (codigo == 3){
        //     preco = 5.00 * qtd;
        //  }
        // if (codigo == 4) {
        //       preco = 2.00 * qtd;
        //  }
        //  if (codigo == 5) {
        //       preco = 1.50 * qtd;
        //  }
        // System.out.println("Preço: R$" + preco);


        //double valor = 1000;
        // char categoria = 'd';

        //if (categoria == 'a') {
        //   double desconto = valor * 0.1;
        //   double precoFinal = valor - desconto;
        //    System.out.println("Desconto de 10% e o preco final é: R$" + precoFinal);
        //  }
        //if (categoria == 'b') {
        //    double desconto = valor * 0.15;
        //    double precoFinal = valor - desconto;
        //  System.out.println("Desconto de 15% e o preco final é: R$" + precoFinal);
        // }
        // if (categoria == 'c') {
        //    double desconto = valor * 0.20;
        //    double precoFinal = valor - desconto;
        //    System.out.println("Desconto de 20% e o preco final é: R$" + precoFinal);
        // }
        //   if (categoria == 'd') {
        //      double acrescimo = valor * 0.05;
        //      double precoFinal = valor + acrescimo;
        //      System.out.println("Acrescimo de 5% e o preco final é: R$" + precoFinal);
        //   }
        // }
        // }


        //soma dos 20 numeros


        // int resultado =  0;
        // int soma = 0;

        // for(int i=5; i<=100; i+=5){
        //   soma = i;
        //  if(i%2 == 1) {
        //  soma = i;
        // }else{
        //    soma = -1*i;
        // }
        //  resultado += soma;
        // }
        // System.out.println("O resultado da soma é: " + resultado);

        // }
//}


        //algoritimo dos 30 primeiros termos

        int resNu = 0, resDeno = 0,somaNu = 0, somaDeno = 0, numerador = 480, denominador = 10;
        for(int i=0; i<30; i++) {

            if (i%2) == 0)
                somaNu = numerador;
            somaDeno = denominador;
        }else{
            somaNu = -1 * numerador;
            somaDeno = -1 * denominador;
        }
        resNu += somaNu;
        resDeno += somaDeno;

        numerador -= 5;
        denominador++;

      }
      System.out.println(resNu + "/" + resDeno);

    }

}











